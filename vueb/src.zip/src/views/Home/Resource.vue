<template>
  <div class="exercise">
    <h1>资源共享</h1>
    <router-view></router-view>
  </div>
</template>

<script>
export default {
  name: "Exercise",
  data() {
    return {
    };
  },
  methods: {
    
  }
};
</script>
<style>
.exercise{
  background-color: #fff;
  margin: 20px 20px 20px 0;
  line-height: 50px;
  width: 790px;
  border-radius: 4px;
}
</style>
