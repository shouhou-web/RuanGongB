<template>
  <div class="profilelevel">
    <h1>This is ProfileLevel</h1>
  </div>
</template>

<script>
export default {
  name: "ProfileLevel",
  data() {
    return {
    };
  },
  methods: {
    
  }
};
</script>
