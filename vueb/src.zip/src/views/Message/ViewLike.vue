<template>
  <div class="viewlike">
    <h1>This is ViewLike</h1>
    <router-view></router-view>
  </div>
</template>

<script>
export default {
  name: "ViewLike",
  data() {
    return {
    };
  },
  methods: {
    
  }
};
</script>
