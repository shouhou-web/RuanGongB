<template>
  <div class="viewsystem">
    <h1>This is ViewSystem</h1>
    <router-view></router-view>
  </div>
</template>

<script>
export default {
  name: "ViewSystem",
  data() {
    return {
    };
  },
  methods: {
    
  }
};
</script>
