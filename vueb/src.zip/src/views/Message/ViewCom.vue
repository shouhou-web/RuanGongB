<template>
  <div class="viewcom">
    <h1>This is ViewCom</h1>
    <router-view></router-view>
  </div>
</template>

<script>
export default {
  name: "ViewCom",
  data() {
    return {
    };
  },
  methods: {
    
  }
};
</script>
